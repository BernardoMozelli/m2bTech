
function msg_alerError() {
    Swal.fire({
        icon: 'error',
        title: 'Erro ao Enviar Formulário',
        Label: 'Ocorreu um erro ao armazenar as informações: " . $stmt->error . "',
        customClass: {
            title: 'swal-custom-title',
            content:'swal-custom-text',
            confirmButton: 'swal-custom-confirm',
            popup: 'swal2-custom-popup'
        }
    });

}

function msg_alertSucess() {
    Swal.fire({
        title: 'Formulário Enviado com Sucesso',
        text: 'Nossa equipe está analisando suas informações e entrará em contato em breve.',
        icon: 'success',
        customClass: {
            title: 'swal-custom-title',
            content:'swal-custom-text',
            confirmButton: 'swal-custom-confirm',
            popup: 'swal-custom-popup'
        }
    }).then(function () {
        window.location.href = 'index.html';
    });

}

function msg_alerErrorvalid(){
    Swal.fire({
        icon: 'error',
        title: 'Erro',
        text: 'Os dados fornecidos são inválidos.',
        customClass: {
            title: 'swal-custom-title',
            content:'swal-custom-text',
            confirmButton: 'swal-custom-confirm',
            popup: 'swal-custom-popup'
        }
    });
}